package com.cg.library.OnlineLibrary.service;

import java.util.List;
import java.util.Optional;

import com.cg.library.OnlineLibrary.bean.Book;

public interface IOnlineLibraryService {
	
	public Optional<Book> showBook(int bookId);

	public void addBook(Book book);

	public void removeBook(int bookId);

	public void updateBook(int bookId,Book book);

	public List<Book> getAllBook();

}
