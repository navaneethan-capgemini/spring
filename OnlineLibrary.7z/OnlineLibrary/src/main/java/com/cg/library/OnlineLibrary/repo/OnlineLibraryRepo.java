package com.cg.library.OnlineLibrary.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.library.OnlineLibrary.bean.Book;

@Repository("OnlineLibrary")
public interface OnlineLibraryRepo extends CrudRepository<Book,Integer> {
	
	

}
