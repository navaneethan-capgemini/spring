package com.cg.library.OnlineLibrary.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.library.OnlineLibrary.bean.Book;
import com.cg.library.OnlineLibrary.repo.OnlineLibraryRepo;
@Service("libraryservice")
public class OnlineLibraryService implements IOnlineLibraryService{
	
	@Autowired
	private OnlineLibraryRepo repo;

	@Override
	public Optional<Book> showBook(int bookId) {
		// TODO Auto-generated method stub
		return repo.findById(bookId);
	}

	@Override
	public void addBook(Book book) {
		// TODO Auto-generated method stub
		repo.save(book);
	}

	@Override
	public void removeBook(int bookId) {
		// TODO Auto-generated method stub
		repo.deleteById(bookId);
		
	}

	@Override
	public void updateBook(int bookId, Book book) {
		// TODO Auto-generated method stub
		repo.save(book);
	}

	@Override
	public List<Book> getAllBook() {
		// TODO Auto-generated method stub
		
		List<Book> mylist=new ArrayList<>();
		repo.findAll().forEach(mylist::add);		
		return mylist;
	}

}
