package com.cg.productcart.exception;

public interface IProductException {
	
	String Error1="Product not present";
}
