package com.cg.productcart.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productcart.beans.Product;
import com.cg.productcart.exception.ProductException;
import com.cg.productcart.service.ProductService;
import com.cg.productcart.service.ProductServiceImpl;

@RestController
public class ProductController {

@Autowired
private ProductServiceImpl service;

@RequestMapping("/products")
public List<Product> getAllProducts(){
	return service.getAllproducts();
}
@RequestMapping("/products/{id}")
public Optional<Product> getProductById(@PathVariable String id) {
	return service.getProductById(id);
	
}
@RequestMapping(value="/products",method=RequestMethod.POST)
public void addProduct(@RequestBody Product p)
{
	service.addProduct(p);
}
@RequestMapping(value="/products/{id}",method=RequestMethod.DELETE)
public String deleteProduct(@PathVariable String id)
{
	
	try{
		return service.deleteProductById(id);
	}
	catch(ProductException e)
	{
		return e.getMessage();
	}
}
@RequestMapping(value="/products/{id}",method=RequestMethod.PUT)
public void updateProduct(@RequestBody Product p,@PathVariable String id) throws ProductException
{
	
		service.updateProduct(p, id);	
}

}
