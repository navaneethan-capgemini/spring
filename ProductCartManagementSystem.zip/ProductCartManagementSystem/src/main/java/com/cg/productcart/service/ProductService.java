package com.cg.productcart.service;

import java.util.List;
import java.util.Optional;

import com.cg.productcart.beans.Product;
import com.cg.productcart.exception.ProductException;

public interface ProductService {
	
	public void addProduct(Product p);
	public void updateProduct(Product p,String id) throws ProductException;
	public String deleteProductById(String id) throws ProductException;
	public List<Product> getAllproducts();
	public Optional<Product> getProductById(String id);
	
	

}
