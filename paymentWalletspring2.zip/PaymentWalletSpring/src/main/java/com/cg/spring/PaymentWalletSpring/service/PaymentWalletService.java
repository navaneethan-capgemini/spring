package com.cg.spring.PaymentWalletSpring.service;

import java.util.List;

import com.cg.library.OnlineLibrary.Exception.PaymentWalletException;
import com.cg.spring.PaymentWalletSpring.dto.Customer;

public interface PaymentWalletService {
	public void createAccount(Customer customer);

	public double showBalance(String number);

	public void deposit(String number, Double amount);

	public String withdraw(String number, Double amount) throws PaymentWalletException;

	public String fundTransfer(String number1, String number2, Double amount) throws PaymentWalletException;

	public String printTransaction(String number);

	public List<Customer> getAllCustomers();
}
