package com.cg.library.OnlineLibrary.Exception;

public interface IPaymentWalletException {

	String Error1="Invalid balance";
}
