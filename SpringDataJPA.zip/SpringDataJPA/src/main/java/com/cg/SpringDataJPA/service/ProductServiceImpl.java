package com.cg.SpringDataJPA.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringDataJPA.beans.Product;
import com.cg.SpringDataJPA.repo.ProductRepo;


@Service("productservice")
public class ProductServiceImpl implements ProductService{

	@Autowired
	private ProductRepo repo;
	
	@Override
	public void addProduct(Product p) {
		// TODO Auto-generated method stub
		repo.save(p);
		
		
	}

	@Override
	public void updateProduct(Product p, String id) {
		// TODO Auto-generated method stub
		repo.save(p);
		
	}

	@Override
	public void deleteProductById(String id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		
	}

	@Override
	public List<Product> getAllproducts() {
		// TODO Auto-generated method stub
		List<Product> list =new ArrayList<>(); 
		repo.findAll().forEach(list::add);
		return list;
	}

	@Override
	public Optional<Product> getProductById(String id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}
	
	

}
