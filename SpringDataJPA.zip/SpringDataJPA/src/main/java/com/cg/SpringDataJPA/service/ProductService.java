package com.cg.SpringDataJPA.service;

import java.util.List;
import java.util.Optional;

import com.cg.SpringDataJPA.beans.Product;

public interface ProductService {
	
	public void addProduct(Product p);
	public void updateProduct(Product p,String id);
	public void deleteProductById(String id);
	public List<Product> getAllproducts();
	public Optional<Product> getProductById(String id);
	
	

}
