package com.cg.spring.repo;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.dto.Product;
@Repository("productrepo")
public class ProductRepoImpl implements IProductRepo{

	private static List<Product> myList=null;
	
	static {
		myList=new ArrayList<>();
		Product p1=new Product("1001","Samsung","s9","10000");
		Product p2=new Product("1002","Samsung","s6","8000");
		Product p3=new Product("1003","iphone","X","50000");
		myList.add(p1);
		myList.add(p2);
		myList.add(p3);
	}

	@Override
	public List<Product>getAllProducts() {
		// TODO Auto-generated method stub
		return myList;
	}

	@Override
	public Product getProductById(String id) {
		for(Product p:myList) {
			if(p.getId().equals(id)) {
				return p;
			}
		}
		return null;
	}

	@Override
	public void addProduct(Product p) {
		// TODO Auto-generated method stub
		myList.add(p);
		
	}

	@Override
	public void updateProduct(Product p,String id) {
		// TODO Auto-generated method stub
		for(int i=0;i<myList.size();i++)
		{
			if(myList.get(i).getId().equals(id))
			{
				myList.set(i,p);
			}
		}
		
	}

	@Override
	public void deleteProduct(String id) {
		// TODO Auto-generated method stub
		for(Product p:myList)
		{
			if(p.getId().equals(id))
			{
				myList.remove(p);
			}
		}
			
	}
	
	
}
