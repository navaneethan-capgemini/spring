package com.cg.linkedin.linkedIn;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LinkedinTest {
	
	private linkedinUtil util;
	private linkedinBeans beans;
	private WebDriver driver;

	@Before
	public void setUp() throws Exception {
		
		util=new linkedinUtil();
		beans=new linkedinBeans();
		driver=util.initiateDriver("chrome");
		PageFactory.initElements(driver,beans);
		
		
		
	}

	@After
	public void tearDown() throws Exception {
		
		driver.close();
	}

	@Test
	public void testpositive() throws Throwable {
		
		the_Linkedin_Homepage();
		all_the_details_are_entered();
		screen_goes_to_another_page();
		
	}
	
	@Test
	public void testnegative() throws Throwable{
		
		the_Linkedin_Homepage();
		all_textboxes_are_blank();
		page_remains_in_the_same_page();
	}
	
	@Given("^The LinkedIn homepage$")
	public void the_LinkedIn_homepage() throws Throwable {
	   
		
		driver.get("https://www.linkedin.com/");
		Thread.sleep(5000);
	    
	}

	@When("^all the details are entered$")
	public void all_the_details_are_entered() throws Throwable {
		
		beans.setFirstname("Navaneethan");
		beans.setLastname("S");
		beans.setEmailid("abc@gmail.com");
		beans.setPassword("newmember");
		beans.getJoinnow();
	   
	}

	@Then("^screen goes to another page$")
	public void screen_goes_to_another_page() throws Throwable {
	
			
		String title=driver.getTitle();
		assertEquals("LinkedIn: Log In or Sign Up",title);
	}
	    

	@Given("^the Linkedin Homepage$")
	public void the_Linkedin_Homepage() throws Throwable {
		
		driver.get("https://www.linkedin.com/");
		Thread.sleep(5000);
		
	   
	}

	@When("^All textboxes are blank$")
	public void all_textboxes_are_blank() throws Throwable {
		
		beans.getJoinnow();
	    
	}

	@Then("^page remains in the same page$")
	public void page_remains_in_the_same_page() throws Throwable {
		
		String title=driver.getTitle();
		assertEquals("LinkedIn: Log In or Sign Up",title);
	    
	}

}
