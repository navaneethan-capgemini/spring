package com.cg.linkedin.linkedIn;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class linkedinBeans {
	
	@FindBy(how=How.ID, id="reg-firstname")
	private WebElement firstname;
	
	@FindBy(how=How.ID,id="reg-lastname")
	private WebElement lastname;
	
	@FindBy(how=How.ID,id="reg-email")
	private WebElement Emailid;
	
	@FindBy(how=How.ID,id="reg-password")
	private WebElement password;
	
	@FindBy(how=How.ID,id="registration-submit")
	private WebElement joinnow;
	
	@FindBy(how=How.ID,id="captcha-title")
	private WebElement security;

	public String getFirstname() {
		return firstname.getAttribute("value");
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}

	public String getLastname() {
		return lastname.getAttribute("value");
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);
	}

	public String getEmailid() {
		return Emailid.getAttribute("value");
	}

	public void setEmailid(String emailid) {
		this.Emailid.sendKeys(emailid);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void getJoinnow() {
		joinnow.click();
	}

	public String getSecurity() {
		return security.getAttribute("value");
	}

	public void setSecurity(String security) {
		this.security.sendKeys(security);
	}
	
	

	
	
	
	

}
