package com.cg.linkedin.linkedIn;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class linkedinUtil {
	
	WebDriver driver;

	public WebDriver initiateDriver(String string) {
		String chrome = "chrome";
		String ie = "ie";
		String firefox = "firefox";
		if (string.equals(chrome)) {
			System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
			driver = new ChromeDriver();
		} else if (string.equals(ie)) {
			driver = new InternetExplorerDriver();
		} else if (string.equals(firefox)) {
			driver = new FirefoxDriver();
		}
		return driver;
	}

}
